package kotlinx.rpc

public const val LIBRARY_VERSION: String = "0.6.1"

@Deprecated("Use kotlinx.rpc.LIBRARY_VERSION instead", ReplaceWith("kotlinx.rpc.LIBRARY_VERSION"))
public const val PLUGIN_VERSION: String = LIBRARY_VERSION

public const val PROTOBUF_VERSION: String = "4.29.3"
public const val GRPC_VERSION: String = "1.69.0"
public const val GRPC_KOTLIN_VERSION: String = "1.4.1"
